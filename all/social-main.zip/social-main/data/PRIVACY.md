# Aviso de Privacidad — Chat P2P Efímero

Este servicio establece conexiones P2P (navegador a navegador) para enviar mensajes efímeros entre participantes.

- Los mensajes se transmiten directamente entre los dispositivos y **no** se almacenan en servidores por defecto.
- Solo se guardan **preferencias y contactos** si el usuario lo acepta expresamente.
- La otra persona puede copiar o fotografiar los mensajes; la app no puede impedir esto.
- Si se usa STUN para mejorar la conexión, puede quedar expuesta la IP pública entre pares. Si se usa TURN (relay), el operador del TURN podría ver el tráfico.
- Si borras caché o cookies del navegador, las preferencias y contactos guardados se perderán.
- Para máxima privacidad: intercambia señales cara a cara (QR) y activa el auto-borrado.

Contacto: tu-email@ejemplo.com
