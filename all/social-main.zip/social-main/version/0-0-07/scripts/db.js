(function(){
  window.AppDB = {
    saveData: function(key, data){
      try { localStorage.setItem(key, JSON.stringify(data)); } catch(e){ console.error(e); }
    },
    getData: function(key){
      try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch(e){ return null; }
    },
    downloadJSON: function(name, obj){
      const blob = new Blob([JSON.stringify(obj,null,2)], {type:'application/json'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = name; a.click(); URL.revokeObjectURL(url);
    }
  };
})();