(function(){
  const btnCreateInvite = document.getElementById('btnCreateInvite');
  const btnScan = document.getElementById('btnScan');
  const btnShowOffer = document.getElementById('btnShowOffer');
  const inviteArea = document.getElementById('inviteArea');
  const inviteText = document.getElementById('inviteText');
  const qrWrap = document.getElementById('qrWrap');
  const btnCopyInvite = document.getElementById('btnCopyInvite');
  const btnDownloadInvite = document.getElementById('btnDownloadInvite');

  const pasteInvite = document.getElementById('pasteInvite');
  const btnAccept = document.getElementById('btnAccept');
  const answerText = document.getElementById('answerText');
  const btnCopyAnswer = document.getElementById('btnCopyAnswer');

  const chatBox = document.getElementById('chatBox');
  const p2pInput = document.getElementById('p2pInput');
  const p2pSend = document.getElementById('p2pSend');
  const status = document.getElementById('status');

  let caller = null;
  let callee = null;

  function logChat(side, text){
    const div = document.createElement('div');
    div.className = 'post';
    div.innerHTML = '<b>'+side+'</b>: '+escapeHtml(text);
    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
  }
  function escapeHtml(s){ if(!s) return ''; return String(s).replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  btnCreateInvite.addEventListener('click', async ()=>{
    inviteArea.style.display='block';
    status.textContent = 'Estado: generando invitación...';
    const res = await window.RTCManual.makeOffer((msg)=> { logChat('Amigo', msg); }, ()=> { status.textContent='Estado: canal abierto (esperando)'; });
    caller = res;
    inviteText.value = res.sdp;
    qrWrap.innerHTML = '';
    try{ QRCode.toCanvas(qrWrap, res.sdp, { width: 200 }, function(err){ if(err) console.error(err); }); }catch(e){ console.warn('QR err', e); }
    status.textContent = 'Estado: invitación lista. Comparte el QR o copia la invitación.';
  });

  btnCopyInvite && btnCopyInvite.addEventListener('click', ()=>{ inviteText.select(); document.execCommand('copy'); alert('Invitación copiada'); });
  btnDownloadInvite && btnDownloadInvite.addEventListener('click', ()=>{ const name='invite-'+Date.now()+'.txt'; const blob=new Blob([inviteText.value], {type:'text/plain'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=name; a.click(); URL.revokeObjectURL(url); });

  btnAccept.addEventListener('click', async ()=>{
    const offer = pasteInvite.value.trim();
    if(!offer){ alert('Pega la invitación primero'); return; }
    status.textContent='Estado: aceptando invitación...';
    const res = await window.RTCManual.acceptOffer(offer, (msg)=>{ logChat('Amigo', msg); }, ()=>{ status.textContent='Estado: canal abierto'; });
    callee = res;
    answerText.style.display='block';
    answerText.value = res.sdp;
    btnCopyAnswer.style.display='inline-block';
    status.textContent='Estado: respuesta generada. Devuélvela al creador.';
  });

  btnCopyAnswer && btnCopyAnswer.addEventListener('click', ()=>{ answerText.select(); document.execCommand('copy'); alert('Respuesta copiada'); });

  p2pSend.addEventListener('click', () => {
    const txt = p2pInput.value.trim();
    if(!txt) return;
    if(caller && caller.send){ caller.send(txt); logChat('Yo', txt); }
    else if(callee && callee.send){ callee.send(txt); logChat('Yo', txt); }
    else { alert('No hay canal abierto. Crea o acepta una invitación.'); return; }
    p2pInput.value='';
  });

})();