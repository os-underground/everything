# POLICIES — v0.0.7
Esta versión 0.0.7 introduce una interfaz simplificada para crear invitaciones P2P y chatear en tiempo real usando WebRTC.
- Las invitaciones (SDP) son de corta duración y deben compartirse con el receptor.
- No hay almacenamiento de mensajes en servidores.
- Consulta POLICIES_LEGALES.md para detalles legales.
