(function(){
  const clearBtn = document.getElementById('clearAll');
  const downloadBtn = document.getElementById('downloadData');
  const age18 = document.getElementById('age18');

  clearBtn.addEventListener('click', function(){
    if(confirm('Eliminará TODO lo guardado en este navegador. Continuar?')){
      window.AppDB.clearAll();
      alert('Datos eliminados. Se recargará la página.');
      location.href = 'index.html';
    }
  });

  downloadBtn.addEventListener('click', function(){
    const data = {
      user: window.AppDB.getData('user') || null,
      posts: window.AppDB.getData('posts') || [],
      contacts: window.AppDB.getData('contacts') || [],
      messages: window.AppDB.getData('messages') || []
    };
    window.AppDB.downloadJSON('backup-social.json', data);
  });

  const u = window.AppDB.getData('user') || {};
  if(u.ageConfirmed) age18.checked = true;
  age18.addEventListener('change', function(){ 
    const u = window.AppDB.getData('user') || {};
    u.ageConfirmed = !!age18.checked;
    window.AppDB.saveData('user', u);
  });
})();