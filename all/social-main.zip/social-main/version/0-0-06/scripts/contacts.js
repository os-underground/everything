(function(){
  const nameIn = document.getElementById('contactName');
  const infoIn = document.getElementById('contactInfo');
  const addBtn = document.getElementById('addContact');
  const listEl = document.getElementById('contactList');
  const fileInput = document.getElementById('fileImport');

  function render(){
    const contacts = window.AppDB.getData('contacts') || [];
    listEl.innerHTML = contacts.map((c, idx)=>(
      '<li><b>'+escapeHtml(c.name||c.id||'Sin nombre')+'</b> — '+escapeHtml(c.info||'')+
      ' <button onclick="(function(i){ var contacts=AppDB.getData(\'contacts\')||[]; contacts.splice(i,1); AppDB.saveData(\'contacts\',contacts); location.reload(); })('+idx+')">Eliminar</button>'+'</li>'
    )).join('');
  }

  function escapeHtml(s){ if(!s) return ''; return String(s).replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  addBtn.addEventListener('click', function(){
    const name = nameIn.value.trim();
    const info = infoIn.value.trim();
    if(!name){ alert('Pon un nombre'); return; }
    const contacts = window.AppDB.getData('contacts') || [];
    contacts.push({ id: 'c-'+Math.random().toString(36).slice(2,8), name: name, info: info });
    window.AppDB.saveData('contacts', contacts);
    nameIn.value=''; infoIn.value='';
    render();
  });

  fileInput.addEventListener('change', function(e){
    const f = e.target.files[0];
    if(!f) return;
    const reader = new FileReader();
    reader.onload = function(){ 
      try{
        const obj = JSON.parse(reader.result);
        const contacts = window.AppDB.getData('contacts') || [];
        const item = { id: obj.id || 'imp-'+Math.random().toString(36).slice(2,6), name: obj.name||obj.id||'importado', info: obj.email||obj.tel||'' };
        contacts.push(item);
        window.AppDB.saveData('contacts', contacts);
        render();
        alert('Importado como contacto');
      }catch(err){ alert('Archivo JSON inválido'); }
    };
    reader.readAsText(f);
  });

  async function tryContactPicker(){
    if(navigator.contacts && navigator.contacts.select){
      try{
        const picked = await navigator.contacts.select(['name','tel','email'], { multiple:true });
        const contacts = window.AppDB.getData('contacts') || [];
        picked.forEach(p => contacts.push({ id: 'c-'+Math.random().toString(36).slice(2,6), name: p.name[0]||'no-name', info: (p.tel && p.tel[0]) || (p.email && p.email[0]) || '' }));
        window.AppDB.saveData('contacts', contacts);
        render();
        alert('Contactos importados desde el dispositivo');
      }catch(e){
        console.warn('Contact picker canceled or not allowed', e);
      }
    }
  }

  // init
  render();
  setTimeout(tryContactPicker, 1200);
})();