(function(){
  const nameEl = document.getElementById('name');
  const bioEl = document.getElementById('bio');
  const saveBtn = document.getElementById('saveProfile');
  const exportBtn = document.getElementById('exportProfile');
  const addPostBtn = document.getElementById('addPost');
  const clearPostsBtn = document.getElementById('clearPosts');
  const newPostEl = document.getElementById('newPost');
  const feedEl = document.getElementById('feed');

  function sanitize(t){
    if(!t) return '';
    return t.replace(/</g,'&lt;').replace(/>/g,'&gt;').trim();
  }

  function renderProfile(){
    const user = window.AppDB.getData('user') || {};
    nameEl.value = user.name || '';
    bioEl.value = user.bio || '';
  }

  function renderFeed(){
    const posts = window.AppDB.getData('posts') || [];
    feedEl.innerHTML = posts.slice().reverse().map(p=>(
      '<div class="post"><div class="small muted">'+p.time+'</div><div><b>'+p.name+'</b></div><div>'+p.text+'</div></div>'
    )).join('');
  }

  saveBtn.addEventListener('click', function(){
    const u = { name: sanitize(nameEl.value), bio: sanitize(bioEl.value), updatedAt: new Date().toISOString() };
    window.AppDB.saveData('user', u);
    alert('Perfil guardado localmente');
  });

  exportBtn.addEventListener('click', function(){
    const u = window.AppDB.getData('user') || {};
    window.AppDB.downloadJSON('profile-'+(u.name||'anon')+'.json', u);
  });

  addPostBtn.addEventListener('click', function(){
    const text = sanitize(newPostEl.value);
    if(!text){ alert('Escribe algo'); return; }
    const posts = window.AppDB.getData('posts') || [];
    const user = window.AppDB.getData('user') || { name: 'Anon' };
    posts.push({ name: user.name || 'Anon', text: text, time: new Date().toLocaleString() });
    window.AppDB.saveData('posts', posts);
    newPostEl.value = '';
    renderFeed();
  });

  clearPostsBtn.addEventListener('click', function(){
    if(confirm('Eliminar todos tus posts locales?')) {
      window.AppDB.saveData('posts', []);
      renderFeed();
    }
  });

  // init
  renderProfile();
  renderFeed();
})();